const search=()=>{
    const searchbox=document.getElementById("search-item").value.toUpperCase();
    // const storeitems=document.getElementById("product-list")
    const product= document.querySelectorAll(".product")
    const names=document.getElementsByTagName("h5")
    // const durations=document.getElementsByClassName("duration")
    // const ratings=document.getElementsByClassName("rating")
    // const prices=document.getElementsByClassName("price")
    
    var maxlength=names.length//>pname2.length?pname.length: pname2.length;
    for (var i=0; i<maxlength;i++){
        
        let matchname=product[i].getElementsByTagName("h5")[0]
        let matchdurations=product[i].getElementsByClassName("duration")[0]
        let matchratings=product[i].getElementsByClassName("rating")[0]
        let matchprices=product[i].getElementsByClassName("price")[0]
        if (matchname || matchdurations || matchratings || matchprices){
            let name= matchname.textContent || matchname.innerHTML
            let duration= matchdurations.textContent || matchdurations.innerHTML
            let rating=matchratings.textContent || matchratings.innerHTML
            let price=matchprices.textContent || matchprices.innerHTML
            if(name.toUpperCase().indexOf(searchbox)>-1 || duration.toUpperCase().indexOf(searchbox)>-1 || rating.toUpperCase().indexOf(searchbox)>-1 || price.toUpperCase().indexOf(searchbox)>-1)
            {
                product[i].style.display="";
            }
            else{
                product[i].style.display="none";
            }
        }
    }
    
}


var modalwrap=null
var modalwrap2=null
const showModal=(obj)=>{
    if (modalwrap!=null){
        modalwrap.remove()
    }
    let parent=obj.parentElement
    let matchname=parent.getElementsByTagName("h5")[0]
    let description=parent.getElementsByClassName("description")[0]
    modalwrap= document.createElement("div")
    modalwrap.innerHTML=
    `
    <div class="modal fade" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    ${matchname.textContent || matchname.innerHTML}
                    <button type="button"  data-dismiss="modal">&times;</button>
                </div>
                <img class="card-img-top" src='${obj.src}' width="500px" height="500px" alt="Card image cap">
                <div class="modal-body text-justify">
                    <p >
                        ${description.textContent || description.innerHTML}
                    </p>
                </div>
            </div>
        
        </div>
    </div>
    `;
    document.body.append(modalwrap)
    var modal=new bootstrap.Modal(document.querySelector(".modal"))
    modal.show()
}
var selectedgenre
var data=["Horror","Action","Adventure","Comedy"]
function showModal2(){
    selectedgenre=[]
    if (modalwrap2!=null){
        modalwrap2.remove()
    }
    var elem=""
    for (var i=0;i< data.length;i++){
        elem+=`                        
        <label for="${i}" class="task">
            <input type="checkbox" name="" onchange="updateGenre(this)" id="${i}">
            ${data[i]}    
        </label>
        `

    }
    modalwrap2= document.createElement("div")
    modalwrap2.innerHTML=
    `
    <div id="modal2" class="modal fade" tabindex="-1">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <div class="form-input text-center">
            <label for="file-ip-1">Upload image</label>
                Upload Movie Poster
                <input type="file"  id="file-ip-1" accept="image/*" onchange="showPreview(event)">
                <div class="preview" style="width:400px; height:400px; margin:0 auto;">
                    <img id="file-ip-1-preview" style="width:400px; height:400px;">
                </div>
                <div class="multi-selector">
                    <div class="select-field"  onclick="toggle()">
                        <input type="text" name="" placeholder="Choose Genre" id="genre" class="input-selector">
                        <span class="down-arrow">&blacktriangledown;</span>
                    </div>
                    <div class="list" >
                    ${elem}

                    </div>
                </div>
        </div>
    </div>
    </div>
</div>
    `
    document.body.append(modalwrap2)
    var modal=new bootstrap.Modal(document.querySelector("#modal2"))
    modal.show()
}
function showPreview(event){
    if(event.target.files.length>0){
        // var src=URL.createObjectURL(event.target.files[0]);
        var src=window.URL.createObjectURL(event.target.files[0]);
        var preview = document.getElementById("file-ip-1-preview")
        preview.src=src

        preview.style.display="block";
        console.log("url" , src)
    }
}
function toggle(){
document.querySelector(".list").classList.toggle("show");
document.querySelector(".down-arrow").classList.toggle("rotate180");
}
function updateGenre(obj){
    if (selectedgenre.includes(data[parseInt(obj.id)])){
        selectedgenre.splice(selectedgenre.indexOf(data[parseInt(obj.id)]),1)
    }
    else{
        selectedgenre.push(data[parseInt(obj.id)])
    }
    console.log(selectedgenre)
}